Thank you for downloading! I hope you enjoy :)
To install, copy this folder into your resourcepacks folder and your world's datapacks folder

Special thanks to Frank The Farmer for helping test the pack. You're the coolest, Frank!!

Mega Lucario can be obtained by giving Lucario a diamond and is just cosmetic